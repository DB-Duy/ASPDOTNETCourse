﻿namespace Shared.DataTransferObjects;

public record EmployeeForCreationDto(string Name, int Age, string Position);
