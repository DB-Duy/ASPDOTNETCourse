﻿namespace Service.Contracts;

public interface IEmployeeService
{
}
