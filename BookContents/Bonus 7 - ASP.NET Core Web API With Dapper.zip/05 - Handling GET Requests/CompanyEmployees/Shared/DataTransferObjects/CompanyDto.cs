﻿namespace Shared.DataTransferObjects
{
    public record CompanyDto(Guid CompanyId, string Name, string FullAddress);
}
