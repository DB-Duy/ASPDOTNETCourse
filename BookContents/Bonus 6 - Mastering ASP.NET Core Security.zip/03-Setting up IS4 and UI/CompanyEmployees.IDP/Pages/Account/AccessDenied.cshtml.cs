using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CompanyEmployees.IDP.Pages.Account;

public class AccessDeniedModel : PageModel
{
    public void OnGet()
    {
    }
}